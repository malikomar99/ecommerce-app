<?php $__env->startSection('content'); ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      <h1 class="h2">Dashboard</h1>
      <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <a href="/addproduct" class="btn btn-success">add new product</a>
         

        </div>
      </div>
    </div>
              <h2>Product Section </h2>
              <?php if(session('massage')): ?>
              <div class="alert alert-success id=msg-box">
                  <?php echo e(session('massage')); ?>

              <?php endif; ?>
              <div class="table-responsive small">
                <table class="table table-striped table-sm">
                  <thead>
                    <tr>
                      
                      <th scope="col">img</th>
                      <th scope="col">title</th>
                      <th scope="col">description</th>
                      <th scope="col">price</th>
                      <th scope="col">quantity</th>
                      <th scope="col">action</th>
                  
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><img src="<?php echo e($pro->images); ?>" class="card-img-top" alt="..." width="100px" height="100px"></td>
                      <td><?php echo e($pro->title); ?></td>
                      <td><?php echo e($pro->description); ?></td>
                      <td><?php echo e($pro->price); ?></td>
                      <td><?php echo e($pro->quantity); ?></td>
                      <td><a onclick="return confirm('you want to delete user?')" href="<?php echo e(route('deleteproduct', ['id'=>$pro->id])); ?>" class="btn btn-danger">delete</a></td>
                      <td><a href="<?php echo e(route('editproduct', ['id'=>$pro->id])); ?>" class="btn btn-primary">update</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\ecommerce-app\resources\views/products.blade.php ENDPATH**/ ?>