<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Orderitems;
use Illuminate\Support\Facades\DB;
use Str;


class AdminController extends Controller
{
    public function addproduct_form(){
        return view ('addproduct');
    }
   
    public function addproduct(Request $request){
        $request->validate([
            'images'=>['required','mimes:png,jpg,jpeg'],
            'title'=>'required',
            'price'=>'required|numeric',
            'quantity'=>'required|numeric',
            'description'=>'required',
        ]);
        $filepath="";
        if ($request->hasfile('images')) {
           $file= $request->file('images');
           $fileExt=$file->getclientoriginalExtension();
           $filename=$file->getclientoriginalname();
           $newname=$filename.'-'.str::random(10).'.'.$fileExt;
           $file->move(public_path('assets/images'),$newname);
           $filepath="assets/images/$newname";
        }
        $product= new product();
        $product->images=$filepath;
        $product->title=$request->title;
        $product->price=$request->price;
        $product->quantity=$request->quantity;
        $product->description=$request->description;
        $product->save();

        return redirect()->route('addproduct')->with('success', 'Product added successfully');   
    }
    public function orderitems(){
        $orderitems=DB::table('Orderitems')->get();
        return view ('orderitems',['orderitems'=>$orderitems]);
    }
    public function products(){
        $products=DB::table('products')->get();

        return view('products',['products'=>$products]);
    }
    public function editproduct($id){
        // $product=product::find($id);
        // dd('$product');
        // return view ('editproduct',['product'=>$product]);
        $product= product::find($id);
        $data['product'] =$product;
        // dd('$product');
        return view('editproduct', $data);
    }
    public function updateproduct(Request $req){
        $product=product::find($req->id);
        // return $product;
        $product->title=$req->title;
        $product->description=$req->description;
        $product->price=$req->price;
        $product->quantity=$req->quantity;
        $product->save();
       

        session()->flash("massage", "user update successfully");
        return redirect()-> route("products");
    }
    public function deleteproduct($id){
        product::find($id)->delete();
        return back()->with("massage","user remove succcessfully");

}
   public function dashboard(){
    return view ('dashboard');
   }
}