<?php

use Illuminate\Support\Facades\Route;



// Auth::routes();
Route::get('/admin', function () {
    return "welcome to teacher route";});

 


