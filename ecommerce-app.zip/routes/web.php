<?php

use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/', [App\Http\Controllers\productController::class, 'products'])->name('welcome');
Route::get('cart', [App\Http\Controllers\productController::class, 'cart'])->name('cart');
Route::get('about', [App\Http\Controllers\productController::class, 'about'])->name('about');
Route::get('/addtocart/{id}', [App\Http\Controllers\productController::class, 'addcart'])->name('addtocart');
Route::get('/addtocart/{id}', [App\Http\Controllers\productController::class, 'addcart'])->name('addtocart');
Route::get('removeitems/{id}', [App\Http\Controllers\productController::class, 'removeitems'])->name('removeitems');
Route::get('checkout', [App\Http\Controllers\OrderController::class, 'checkout'])->name('checkout');
Route::post('process-order', [App\Http\Controllers\OrderController::class, 'process_order'])->name('process.order');
            // admin routes
// Route::prefix('admin')->group(['middleware'=>'auth'],function(){      });     
Route::get('addproduct',[App\Http\Controllers\AdminController::class,'addproduct_form'])->name('addproduct_form');
Route::post('addproduct',[App\Http\Controllers\AdminController::class,'addproduct'])->name('addproduct');
Route::get('editproduct/{id}',[App\Http\Controllers\AdminController::class,'editproduct'])->name('editproduct');
Route::get('products',[App\Http\Controllers\AdminController::class,'products'])->name('products');
Route::post('orderitems',[App\Http\Controllers\AdminController::class,'orderitems'])->name('orderitems');
Route::post('updateproduct',[App\Http\Controllers\AdminController::class, 'updateproduct'])->name("updateproduct");
Route::get('dashboard',[App\Http\Controllers\AdminController::class, 'dashboard'])->name("dashboard");

Route::get('deleteproduct/{id}',[App\Http\Controllers\AdminController::class, 'deleteproduct'])->name("deleteproduct");



